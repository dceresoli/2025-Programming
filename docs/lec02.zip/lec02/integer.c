#include <stdlib.h>
#include <stdio.h>

int main()
{
   unsigned char a = 170;
   unsigned char two_a = a * 2;

   printf("a = %i\n", a);
   printf("2*a = %i\n", two_a);

   return 0;
}
